This wrapper displays an in-game, FRAPS-like FPS counter. Requires an S3d card.
ArtisaaniSoft, 2025.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
    DEALINGS IN THE SOFTWARE.


Compatibility
=============

The wrapper doesn't support DOS programs.

The following Win32 programs are known to exhibit issues on at least some
systems:

    - MechWarrior 2:
      Counter doesn't update, stays at 0. Use the "Workaround" INI setting,
      which may or may not give an accurate reading.
    
    - Croc:
      Counter flickers.
    
    - Havoc:
      Counter doesn't appear. Use the "Workaround" INI setting.
    
    - FX Fighter Turbo:
      Counter looks odd. Use the "Workaround" INI setting.
