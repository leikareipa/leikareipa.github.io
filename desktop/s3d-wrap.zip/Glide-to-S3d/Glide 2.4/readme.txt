This is an alpha-level Glide wrapper for the S3d API, translating Glide 2.4
calls into S3d. ArtisaaniSoft, 2025.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
    DEALINGS IN THE SOFTWARE.


System requirements
===================

An OS supported by the Glide application being run.

An S3d compatible video card (e.g. S3 ViRGE/DX) with at least 4 MB of video
memory. A 2 MB card may work in games that use guTexAllocateMemory instead of
grTexDownloadMipMap, but performance will be impacted compared to a 4 MB card.

A Pentium 2 or better could be recommended.


Compatibility report
====================

The author has briefly tested some versions of the wrapper with the following
applications using an emulated ViRGE/DX in 86Box.

APPLICATION                 STATUS      NOTES
-------------------------------------------------------------------------------
Chaga                       Broken      Opens a blank window and exits.

Crazy Marbles               Broken      Wrapper is missing 3DF utilities.

Croc 1.0                    Playable    Some alpha blending issues. Heavy
                                        flickering in the game-over screen.

Formula 1                   Runs        Glitched menus; in-game totally broken.

Formula 1 97 (demo)         Runs        Glitched menus; no textures in-game.

GLQuake (MiniGL 1.49)       Runs        Severe texture glitches.
                                
Ignition                    Playable    Intro cinematic needs to be skipped to
                                        avoid system freeze (rapid fire Enter
                                        at the language selection screen).
                                        Minor to medium visual gliches.

MGP: Racing Simulation 2    Runs        Menus work; in-game is totally broken.

Monster Truck Madness 2     Broken      Renders one glitched frame, then
                                        crashes the system.

Need for Speed 2 SE         Runs        Some corruption in menus. Exits when
                                        attempting to enter a race.

Quake 2 (MiniGL 1.49)       Runs        Severe texture glitches.

Redline Racer               Runs        Menus mostly work, in-game is fairly
                                        glitched.

Volcano (demo)              Broken      Exits on startup.
