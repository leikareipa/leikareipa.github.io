This is a set of wrappers for the 1990s S3d API. Some of the wrappers provide
software-rendered implementations of S3d for running S3d applications without
an S3 graphics card; while others are tools to enhance the S3d experience on
real hardware. ArtisaaniSoft, 2025. No affiliated with S3.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
    DEALINGS IN THE SOFTWARE.


The wrappers
============

glide-s3d..................Glide-to-S3d wrapper
    glide2x................Generic for Glide 2.4
    ignition...............Optimized for Ignition
    
s3d-software...............S3d-to-software wrapper
    reference..............Generic for S3d 2.6 (not compatible with old games)
    destruction-derby......Optimized for Destruction Derby
    havoc..................Optimized for Havoc
    pod....................Optimized for POD
    
tools
    calltrace..............Outputs a call trace of S3d & DirectDraw into stdout
    fps-overlay............FRAPS-like FPS counter in S3d applications

Each wrapper is described in more detail in its corresponding readme file.


Usage
=====

Put the DLL and its corresponding INI file next to the executable you want to
run. The INI file contains additional settings for you to tweak.

See the sub-directories for more information.
