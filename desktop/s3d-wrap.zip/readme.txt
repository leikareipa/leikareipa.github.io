This is a set of wrappers for the 1990s S3d API. Some of the wrappers provide
software-rendered implementations of S3d for running S3d applications without
an S3 graphics card; while others are tools to enhance the S3d experience on
real hardware. ArtisaaniSoft, 2025. No affiliated with S3.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
    DEALINGS IN THE SOFTWARE.


The wrappers
============

/Glide-to-S3d:
    /Glide 2.4:        Glide-to-S3d for Glide 2.4.
/S3d-to-Software:
    /DestructionDerby: S3d-to-software for Destruction Derby.
    /Havoc:            S3d-to-software for Havoc.
    /POD:              S3d-to-software for POD.
    /Reference:        S3d-to-software for for version 2.6 of the S3d API.
/Tools:
    /CallTrace:        Outputs an S3d and DirectDraw call trace into stdout.
    /FPSOverlay:       FRAPS-like FPS counter.

Each wrapper is described in more detail in its corresponding readme file.


Usage
=====

Put the S3DTKW.DLL and S3DTKW.INI files next to the S3d executable you want to
run. The INI file contains additional settings for you to tweak.

See the sub-directories for more information.
