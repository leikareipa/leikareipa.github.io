This is a set of wrappers for the 1990s S3d API. Some of the wrappers provide
software-rendered implementations of S3d for running S3d applications without
an S3 graphics card; while others are tools to enhance the S3d experience on
real hardware. ArtisaaniSoft, 2025. No affiliated with S3.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
    DEALINGS IN THE SOFTWARE.


Usage
=====

Put the DLL and its corresponding INI file next to the executable you want to
run. The INI file contains additional settings for you to tweak.

Each wrapper is described in more detail in its corresponding readme file.
