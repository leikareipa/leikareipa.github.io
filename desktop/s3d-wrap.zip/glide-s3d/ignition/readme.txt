This is a Glide-to-S3d wrapper optimized for Ignition. ArtisaaniSoft, 2025.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
    DEALINGS IN THE SOFTWARE.


System requirements
===================

- An OS supported by Ignition

- An S3d compatible video card (e.g. S3 ViRGE)

- Pentium 2 or better


Troubleshooting
===============

- The intro cinematic, following the language selection screen, must be skipped
  or the system will freeze. Rapid-fire Enter at the language selection until
  you're in-game.

- There are some minor visual glitches here and there. Nothing to be alarmed
  about. Occasional freezes may also happen, which is less ideal.

- If the game's textures look very low resolution, make sure your S3d card has
  at least 4 MB of VRAM. For full resolution textures, you need 8 MB of VRAM;
  though it's not known whether cards of that sort, e.g. S3 Trio3D, support S3d
  well enough to work with this wrapper.
