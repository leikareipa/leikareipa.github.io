This is an alpha-level Glide wrapper for the S3d API, translating Glide 2.4
calls into S3d. ArtisaaniSoft, 2025.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
    DEALINGS IN THE SOFTWARE.


System requirements
===================

An OS supported by the Glide application you want to run.

An S3d compatible video card, ideally with at least 4 MB of video memory.

A Pentium 2 or better could be recommended.


Troubleshooting
===============

The S3d platform is considerably less performant and more feature poor than the
Glide platform. As such, many Glide games will simply not work well on S3d, and
this should be your baseline expectation when using the wrapper.

That said, some games do work, and for those that don't, the GLIDE2X.INI file
provides some options for you to tweak to try and make them work.

If you find a game crashes on loading or displays corrupted textures, try
increasing ReduceTextureLOD to reduce the amount of VRAM required for textures.
Although your S3d card might have 4 MB of VRAM, the same as the Voodoo, some
Glide games use paletted textures, which S3d doesn't support. These textures
have to be converted into 16-bit formats at twice the VRAM cost, in which case
your only alternative is to reduce the texture resolution to make up the
difference.

If a game freezes after brief gameplay, try disabling AllowPerspectiveCorrect.
S3d appears to be more sensitive to bad vertex values etc. when perspective
correct texture mapping is enabled; disabling it can often fix this. The
downside is that it tends to have a fairly negative effect on visual quality.


Compatibility report
====================

The author has briefly tested some versions of the wrapper with the following
applications using an emulated ViRGE/DX in 86Box.

APPLICATION                 STATUS      NOTES
-------------------------------------------------------------------------------
Chaga                       Broken      Exits on launch.

Crazy Marbles               Broken      Exits on launch.

Croc 1.0                    Playable    Some alpha blending issues. Heavy
                                        flickering in the game-over screen.
                                        
Die by the Sword (demo)     Broken      Exits on launch.

Formula 1                   Runs        Menus and in-game very glitchy.

Formula 1 97 (demo)         Runs        Menus and in-game fairly glitchy.

GLQuake (MiniGL 1.49)       Runs        Brings up the console for a few
                                        seconds, then exits.

Grand Prix Legends (demo)   Broken      Gets stuck trying to start.
                                
Ignition                    Playable    Intro cinematic needs to be skipped to
                                        avoid system freeze. Minor visual
                                        gliches.

Monaco Grand Prix: Racing
Simulation 2                Runs        In-game completely glitched.

Monster Truck Madness 2
(demo)                      Playable    Various visual glitches.

Need for Speed 2 SE         Runs        Glitchiness in the menus. In-game very
                                        glitched.

POD                         Runs        Menus don't display. In-game fairly
                                        glitchy.

Redline Racer               Runs        Exits on load screen.

Volcano (demo)              Broken      Wrapper is missing 3DF utilities.
