UFO (c) 1996 Sigmoid Colon

Deliver five of your alien seed to the Finnish countryside.

Use the arrow keys to rotate your craft and Space to thrust. Ctrl fires
the cannon. Esc exits the game.

You must land a seed onto each of the five tiles marked on your minimap.
Use your cannon to clear the tile and then gently bring your craft down
on it. Any mistake and you die.

The game runs in Windows 95 and requires a Pentium and an S3 ViRGE. You
may edit the UFO.INI file to increase the game's color depth from 16 to
24 bits, but depending on how the stars align this may not work well.
