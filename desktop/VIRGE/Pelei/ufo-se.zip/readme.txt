UFO Special Edition (c) 1996 Sigmoid Colon

Deliver five of your alien seed to the Finnish countryside.

Use the arrow keys to rotate your craft and Space to thrust. Ctrl fires
the cannon. Esc exits the game.

You must land a seed onto each of the five tiles marked on your minimap.
Use your cannon to clear the tile and then bring your craft down on it.
Any mistake and you die.
